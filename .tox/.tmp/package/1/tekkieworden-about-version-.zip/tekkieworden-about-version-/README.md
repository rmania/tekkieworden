
Activate virtual env
`virtualenv venv`
`source venv/bin/activate`

mismatch arbeidsmarkt. Er zijn afstudeerders (quantiteit) doelgroepen ondervertegenwoordigd
Bepaalde profielen hebben een mismatch aanbod vs vraag. Dit willen we inzichtelijk maken dmv een Gap report. 
Dit moet inzichtelijk maken waar we het over hebben: mist er opleidingscapaciteit en in welke sectoren
/opleidingen. 

Haarlem: 70/80% gaan naar Amsterdam:hoeveel data analisten gaan elke dag naar Amsterdam. Spreiding en mismatch
: minsterieOVW : als jullie opleidingen ter beschikking, extra support aan make IT work, --> verkleining 
Culurele diversiteit : Start-up: wat is het probleem: hoe wordt het aanbod

**TechConnect**: https://techconnect.city/
Komende vier jaar gaat TechConnect 50.000 extra mensen —uit ondervertegenwoordigde groepen— 
de tech-arbeidsmarkt laten bestormen. In de praktijk betekent dit duizenden vrouwen, mensen uit sociaal 
kansarmere wijken, grote groepen 40-plussers en MKB’ers die tot programmeur, data-analist, ‘growth hacker’, 
UX ontwerper of tech-beheer worden opgeleid. 

**TekkieWorden**: https://tekkieworden.nl/
Gids welke tech-banen er zijn, welke profielen. GAP report als aanjager en pressiemiddel: 
investeringen aanjagen op de juiste plekken.  

Mogelijke andere interessante sources:
- **DUO**: Dienst Uitvoering Onderwijs. DUO verzamelt gegevens over het bekostigde onderwijs in Nederland en
stelt daarvan een grote hoeveelheid online beschikbaar. Hiermee speelt DUO in op de toenemende vraag naar 
onderwijsgegevens vanuit gemeenten, scholen, onderzoeksbureaus, dagbladen, softwareleveranciers en andere 
partijen die geïnteresseerd zijn in het onderwijsveld. De gegevens gaan over leerlingen, diploma's, personeel,
financiën, samenwerkingsverbanden of de locatie vanscholen. DUO stelt de gegevens en worden beschikbaar 
gesteld, zodat anderen zelf informatieproducten kunnen ontwikkelen. Zo kunnen de gegevens gebruikt worden 
voor het uitvoeren van beleid, als vulling voor webapplicaties of als onderzoeksdata. 
API docs: https://duo.nl/open_onderwijsdata/images/technische-toelichting-gebruik-duo-api-met-open-onderwijsdata.pdf

vacature kant: vraag-kant KOPPELEN aan opleidingscapacit(aanbod) op kwantiteit en doelgroepen.
vraag kant: 
https://docs.google.com/spreadsheets/d/1soBQBGeI64vzG9qI1LY6Dm5Gh9pmhrbJgMiTPSMEbBc/edit?ts=5e984e2f#gid=1223856996
Aanbod kant: 
https://docs.google.com/spreadsheets/d/1_rcDwsnP4YrTrAhhnZurolSvhwSjPMJpE3iuza5J3H0/edit#gid=0
